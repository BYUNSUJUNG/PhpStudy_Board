<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
<head>
    <?php require("html_head.php") ?>
</head>
<body>
    <?php require("top_nav.php") ?>
    <?php require("nav.php") ?>
    <?php require("companySidebar.php") ?>
    <div class="container">		
        <h2>회사소개</h2>
        <img class="button_left" src="images/companyInformation1.jpg" alt="피자" />
        <img class="button_left" src="images/companyInformation2.jpg" alt="피자" />
        <img class="button_left" src="images/companyInformation3.jpg" alt="피자" />
    </div>
</body>
</html>
