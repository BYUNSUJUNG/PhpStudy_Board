<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        COMPANY
    </button>
    <a href="companyInformation.php"><button type="button" class="list-group-item list-group-item-action">회사소개</button></a>
    <a href="companyHistory.php"><button type="button" class="list-group-item list-group-item-action">회사연혁</button></a>
    <a href="companyLocation.php"><button type="button" class="list-group-item list-group-item-action">찾아오는길</button></a>
</div>