<nav class="navbar navbar-expand-lg nav" style="background-color: white;">
    <div class="collapse navbar-collapse nav_content" id="navbarTogglerDemo01">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
                <a href="menu.php"><img src="images/menu.jpg" alt="menu"/></a>
            </li>
            <li class="nav-item">
                <a href="store.php"><img src="images/store.jpg" alt="store"/></a>
            </li>         
            <li class="nav-item">
                <a href="customerNotices.php"><img src="images/customer.jpg" alt="customer"/></a>
            </li>
            <li class="nav-item">
                <a href="companyInformation.php"><img src="images/company.jpg" alt="company"/></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">집게리아 사람들</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" href="#">고객센터</a>
            </li>
        </ul>
    </div>
</nav>