<style type="text/css">
    

    a:link {text-decoration:none;}
              
    article {
        background-color: white;
        width: 1500px;
        height: 1000px;
        margin-top: 15%;
        margin-left: 15%;
        border-radius: 10px;
        padding: 3%;
    }

    footer {
        margin-top: 10%;
    }

    
</style>