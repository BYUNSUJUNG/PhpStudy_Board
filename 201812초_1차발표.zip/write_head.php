<style type="text/css">

    label {
        float:left;
        font-weight: 600;

    }
    article {
        background-color: white;
        width: 800px;
        height: 700px;
        border-radius: 10px;
        padding: 3%;
    }
</style>