<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        MENU
    </button>
    <a href="menuBurger.php"><button type="button" class="list-group-item list-group-item-action">버거 메뉴</button></a>
    <a href="menuchicken.php"><button type="button" class="list-group-item list-group-item-action">치킨 메뉴</button></a>
    <a href="menuSide.php"><button type="button" class="list-group-item list-group-item-action">사이드 메뉴</button></a>
    <a href="menuDrink.php"><button type="button" class="list-group-item list-group-item-action">음료류</button></a>
</div>