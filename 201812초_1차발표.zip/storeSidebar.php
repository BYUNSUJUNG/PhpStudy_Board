<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        STORE
    </button>
    <a href="storeNationwideFranchise.php"><button type="button" class="list-group-item list-group-item-action">전국 가맹점 찾기</button></a>
    <a href="storeNewFranchise.php"><button type="button" class="list-group-item list-group-item-action">신규 오픈매장</button></a>
    <a href="storeGallery.php"><button type="button" class="list-group-item list-group-item-action">사진 갤러리</button></a>
</div>